// Small enhancements: mobile nav, smooth-scroll, dynamic year, map link helper
const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.getElementById('nav-menu');
navToggle?.addEventListener('click', () => {
  const open = navMenu.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(open));
});

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if (id.length > 1) {
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  });
});

// Year
document.getElementById('year').textContent = new Date().getFullYear();

// Map link auto update
(function initMapLink(){
  const locEl = document.getElementById('event-location');
  const mapLink = document.getElementById('map-link');
  const update = () => {
    const q = encodeURIComponent(locEl.textContent.replace(/\[|\]/g, '').trim());
    if (q && mapLink) { mapLink.href = `https://www.google.com/maps/search/?api=1&query=${q}`; }
  };
  update();
})();
